// Homework 1 - Park

#include <stdio.h>
#include <stdlib.h>

int matrix_size, park_size, center_edge_offset, min_rock_num;

char* load_input();
int find_rocks();

int main() {
    char * matrix = load_input();

    int answer = find_rocks(matrix, park_size, center_edge_offset, matrix_size, min_rock_num);
    
    fprintf(stdout, "%d\n", answer);

    free(matrix);

    return 0;
}

char* load_input() {
    if (fscanf(stdin, "%d %d %d %d", &matrix_size, &park_size, &center_edge_offset, &min_rock_num) != 4) {
        fprintf(stderr, "ERROR: nepodarilo se nacist 4 potrebne parametry.\n");
        exit(100);
    }

    char *main_matrix = malloc(matrix_size * matrix_size * sizeof(char));
    if (!main_matrix) {
        fprintf(stderr, "ERROR: malloc fail.\n");
        exit(102);
    }

    for (int row = 0; row < matrix_size; row++) {
        for (int col = 0; col < matrix_size; col++) {
            if (fscanf(stdin, "%d", (int*)&main_matrix[row * matrix_size + col]) != 1) {
                fprintf(stderr, "ERROR: nepodarilo se nacist prvek matice.\n");
                exit(101);
            }
        }
    }

    return main_matrix;
}

int find_rocks(const char *matrix, int park_size, int center_edge_offset, int matrix_size, int min_rock_num) {

    int center_block_size = park_size - (2 * center_edge_offset);
    int max_tree_count = 0;

    for (int top = 0; top <= matrix_size - park_size; top++) {
        for (int left = 0; left <= matrix_size - park_size; left++) {
            
            int rock_count = 0;
            for (int r = 0; r < center_block_size; r++) {
                for (int c = 0; c < center_block_size; c++) {
                    int row = top + center_edge_offset + r;
                    int col = left + center_edge_offset + c;
                    if (matrix[row * matrix_size + col] == 2) {
                        rock_count++;
                    }
                }
            }

            if (rock_count >= min_rock_num) {
                int tree_count = 0;
                for (int r = 0; r < park_size; r++) {
                    for (int c = 0; c < park_size; c++) {
                        int row = top + r;
                        int col = left + c;
                        if (matrix[row * matrix_size + col] == 1) {
                            tree_count++;
                        }
                    }
                }
                
                if (tree_count > max_tree_count) {
                    max_tree_count = tree_count;
                }
            }
        }
    }

    return max_tree_count;
}